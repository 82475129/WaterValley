# Water / Aqua Valley

這是一個可以直接上傳 GitHub 的完整 GitHub Pages 專案。

## 上傳後檔案結構

Water/
├─ index.html
├─ README.md
├─ .github/
│  └─ workflows/
│     └─ pages.yml
├─ web/
│  ├─ css/
│  │  └─ style.css
│  ├─ js/
│  │  └─ app.js
│  └─ data/
│     └─ game-data.json
└─ docs/
   └─ game/
      └─ index.html

## GitHub Pages 設定

Settings → Pages → Source 選 GitHub Actions

部署網址範例：

https://82475129.github.io/Water/

## Unity WebGL

之後 Unity Build WebGL 後，把輸出的檔案放進 docs/game/
